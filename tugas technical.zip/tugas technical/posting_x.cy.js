/// <reference types="cypress" />

context('Log In to X', () => {
    beforeEach(() => {
      cy.visit('https://x.com/i/flow/login')
    })

    it('Log In successfully then tweet', () => {
      cy.get('.r-1roi411 > :nth-child(1) > .r-16y2uox').type('akbarmaulanarizky7337@gmail.com')
      cy.contains('Next').click()
      cy.contains('Phone').type('@katong_ranger')
      cy.contains('Next').click()
      cy.contains('Password').type('alan7337')
      cy.contains('Log in').click()
      cy.get('.public-DraftStyleDefault-block').type('this is my first test')
      cy.contains('Post').click()
    })
  })