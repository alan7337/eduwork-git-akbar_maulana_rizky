/// <reference types="cypress" />

context('Log In to X', () => {
    beforeEach(() => {
      cy.visit('https://ppid.tubankab.go.id/')
    })

    it('Log In successfully then tweet', () => {
      cy.get('[style="width:auto;padding-bottom: 35px;padding-top:35px;"] > :nth-child(1) > :nth-child(1) > .text-center > a > .wow').click()
      cy.get(':nth-child(1) > :nth-child(6) > .btn').click()
      cy.get('.btn').click()
    })
  })