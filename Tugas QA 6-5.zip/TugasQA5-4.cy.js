/// <reference types="cypress" />

describe('Working with inputs', () => {
    it('Visit the website', () => {
        cy.visit('https://www.saucedemo.com/', {timeout: 10000})
        cy.url().should('include', 'saucedemo.com')
    })

    it('Should try to login', () => {
        cy.fixture('anotherUser').then(anotherUser => {
            const username1 = anotherUser.username1
            const password = anotherUser.password

            cy.get('#user-name').clear()
            cy.get('#user-name').type(username1)

            cy.get('#login-button').click()

            cy.get('#add-to-cart-sauce-labs-backpack').click()
            cy.get('.shopping_cart_badge').click()

            cy.get('#checkout').click()

            cy.get('#first-name').clear()
            cy.get('#first-name').type('john')

            cy.get('#last-name').clear()
            cy.get('#last-name').type('doe')

            cy.get('#postas-code').clear()
            cy.get('#postal-code').type('12345678')

            cy.get('#continue').click()

            cy.get('#finish').click()

            cy.get('#back-to-products').click()
        })
    })
})
