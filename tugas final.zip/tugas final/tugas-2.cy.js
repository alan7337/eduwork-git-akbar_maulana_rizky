/// <reference types="cypress" />

context('Log In to eduwork', () => {
  // Handle uncaught exceptions
  Cypress.on('uncaught:exception', (err, runnable) => {
    // Returning false here prevents Cypress from failing the test
    return false
  })

  beforeEach(() => {
    cy.visit('https://eduwork.id/login')
  })

  it('LogIn successfully', () => {
    cy.get('#btn-login-modal').click()
    cy.get('[name="phone"]').type('akbarmaulanarizky7337@gmail.com')  
    cy.get('[name="password"]').type('alan7337') 
    cy.get('#modalLogin > .h-full > .relative > .space-y-6 > .flex-col > .bg-primary').click()
  })

  it('LogIn with incorrect email and correct password', () => {
    cy.get('#btn-login-modal').click()
    cy.get('[name="phone"]').type('abarmaulanarizky7337@gmail.com')  
    cy.get('[name="password"]').type('alan7337') 
    cy.get('#modalLogin > .h-full > .relative > .space-y-6 > .flex-col > .bg-primary').click()
    cy.end()
  })

  it('LogIn with correct email and incorrect password', () => {
    cy.get('#btn-login-modal').click()
    cy.get('[name="phone"]').type('akbarmaulanarizky7337@gmail.com')  
    cy.get('[name="password"]').type('aan7337') 
    cy.get('#modalLogin > .h-full > .relative > .space-y-6 > .flex-col > .bg-primary').click()
    cy.end()
  })

  it('LogIn with incorrect email and password', () => {
    cy.get('#btn-login-modal').click()
    cy.get('[name="phone"]').type('armaulanarizky7337@gmail.com')  
    cy.get('[name="password"]').type('an7337') 
    cy.get('#modalLogin > .h-full > .relative > .space-y-6 > .flex-col > .bg-primary').click()
    cy.end()
  })

  it('Will request recovery email', () => {
    cy.get('#btn-login-modal').click()
    cy.get('#modalLogin > .h-full > .relative > .space-y-6 > .flex-col > .text-primary').click()
    cy.get('#email').type('akbarmaulanarizky7337')
    cy.contains('Reset Password').click()
  })

  it('Will request recovery email from unregistered email', () => {
    cy.get('#btn-login-modal').click()
    cy.get('#modalLogin > .h-full > .relative > .space-y-6 > .flex-col > .text-primary').click()
    cy.get('#email').type('akbarmaulanarizky77')
    cy.contains('Reset Password').click()
  })
})
