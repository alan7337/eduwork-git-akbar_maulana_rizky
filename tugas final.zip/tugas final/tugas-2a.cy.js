/// <reference types="cypress" />

context('Log In to eduwork', () => {
  // Handle uncaught exceptions
  Cypress.on('uncaught:exception', (err, runnable) => {
    // Returning false here prevents Cypress from failing the test
    return false
  })

  beforeEach(() => {
    cy.visit('https://eduwork.id/login')
  })

  it('LogIn successfully', () => {
    cy.get('#btn-login-modal').click()
    cy.get('[name="phone"]').type('akbarmaulanarizky7337@gmail.com')  
    cy.get('[name="password"]').type('alan7337') 
    cy.get('#modalLogin > .h-full > .relative > .space-y-6 > .flex-col > .bg-primary').click()
  })
})
