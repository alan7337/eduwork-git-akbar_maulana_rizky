/// <reference types="cypress" />

context('Log In to eduwork', () => {
    // Handle uncaught exceptions
    Cypress.on('uncaught:exception', (err, runnable) => {
      // Returning false here prevents Cypress from failing the test
      return false
    })
  
    beforeEach(() => {
      cy.visit('https://eduwork.id/login')
    })
  
    it('Will request recovery email', () => {
        cy.get('#btn-login-modal').click()
        cy.get('#modalLogin > .h-full > .relative > .space-y-6 > .flex-col > .text-primary').click()
        cy.get('#email').type('akbarmaulanarizky7337')
        cy.contains('Reset Password').click()
      })
  })
  