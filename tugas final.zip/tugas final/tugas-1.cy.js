/// <reference types="cypress" />

context('BMI Calculator', () => {
    beforeEach(() => {
      cy.visit('https://fitbybeat.com/')
    })

    it('will fill the BMI Colum', () => {
      cy.get('.qodef-grid-row > :nth-child(1) > input').type('180')
      cy.get(':nth-child(2) > input').type('80')
      cy.get(':nth-child(3) > input').type('30')
      cy.get('select[name="sex"]').select('Male', {force: true})
      cy.get('select[name="activity_level"]').select('light', {force: true})
      cy.get(':nth-child(6) > .qodef-btn > .qodef-btn-text').click()

      cy.get('.qodef-bmic-notification-highlight').should('have.text', 'You are Healthy! ')

    })
  })
  